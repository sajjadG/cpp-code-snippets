/*
--
<sad>
<?php phpinfo(); ?>
*/
